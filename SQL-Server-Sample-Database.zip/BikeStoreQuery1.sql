select 
 ord.order_id,
 CONCAT(cus.first_name, ' ', cus.last_name) AS customers,
 cus.city,
 cus.state,
 ord.order_date,
 SUM(item.quantity) AS 'total_units',
 SUM(item.quantity * item.list_price) AS 'revenue',
 pro.product_name,
 brand.brand_name
 ,
 cat.category_name,
 store.store_name,
 CONCAT(staf.first_name, ' ',staf.last_name) AS 'sales_rep'


FROM sales.orders ord
JOIN sales.customers cus
ON ord.customer_id = cus.customer_id
JOIN sales.order_items item
ON ord.order_id = item.order_id
JOIN production.products pro
ON item.product_id = pro.product_id
JOIN production.categories cat
ON pro.category_id = cat.category_id
JOIN sales.stores store
ON ord.store_id = store.store_id 
JOIN sales.staffs staf
ON ord.staff_id = staf.staff_id
JOIN production.brands brand
ON pro.brand_id = brand.brand_id
GROUP BY
 ord.order_id,
 CONCAT(cus.first_name, ' ', cus.last_name),
 cus.city,
 cus.state,
 ord.order_date,
 pro.product_name,
  brand.brand_name,
 cat.category_name,
  store.store_name,
 CONCAT(staf.first_name, ' ',staf.last_name)
 ;